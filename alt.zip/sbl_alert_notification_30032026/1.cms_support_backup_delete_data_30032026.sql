-- -----------------------------------------
-- backup tables
-- -----------------------------------------

CREATE TABLE cms_support.ALERT_CONFIG_PRIMARY_30032026 AS SELECT * FROM cms_support.ALERT_CONFIG_PRIMARY;
CREATE TABLE cms_support.ALERT_PRIMARY_30032026 AS SELECT * FROM cms_support.ALERT_PRIMARY;
CREATE TABLE cms_support.ALERT_TEMPLATE_PRIMARY_30032026 AS SELECT * FROM cms_support.ALERT_TEMPLATE_PRIMARY;
CREATE TABLE cms_support.SEQUENCE_MASTER_30032026 AS SELECT * FROM cms_support.SEQUENCE_MASTER;
CREATE TABLE cms_support.ALERT_FOLLOWUP_TRIGGER_30032026 AS SELECT * FROM cms_support.ALERT_FOLLOWUP_TRIGGER;
CREATE TABLE cms_support.ALERT_TRIGGER_30032026 AS SELECT * FROM cms_support.ALERT_TRIGGER;

-- ---------------------------------------------------------
-- truncate table
-- ---------------------------------------------------------
truncate table cms_support.ALERT_TRIGGER;
truncate table cms_support.ALERT_FOLLOWUP_TRIGGER;
truncate table cms_support.SEQUENCE_MASTER;
truncate table cms_support.ALERT_TEMPLATE_PRIMARY;
truncate table cms_support.ALERT_PRIMARY;
truncate table cms_support.ALERT_CONFIG_PRIMARY;